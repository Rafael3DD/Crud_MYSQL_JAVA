package DAONoSQL;


public class Aluno {
	private float nota;
	private String nome, RA;
	
	public Aluno(String nome, float nota, String RA) {
		super();
		this.nome = nome;
		this.nota = nota;
		this.RA = RA;
	}
	 
	
	public float getNota() {
		return nota;
	}
	public void setNota(float nota) {
		this.nota = nota;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getRA() {
		return RA;
	}
	public void setRA(String rA) {
		RA = rA;
	}
	
	
	
}
