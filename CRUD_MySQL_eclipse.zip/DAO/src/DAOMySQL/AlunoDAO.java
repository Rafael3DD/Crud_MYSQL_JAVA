package DAOMySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAO {
	private float nota;
	private String nome, RA;
	
	public float getNota() {
		return nota;
	}


	public void setNota(float nota) {
		this.nota = nota;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getRA() {
		return RA;
	}


	public void setRA(String rA) {
		RA = rA;
	}


	public static void main(String[] args) {
		AlunoDAO al = new AlunoDAO();
		al.setNome("torta");
		al.setNota(10);
		al.setRA("202211");
		
		al.Buscar(al);
		
		//al.cadastrar(al);
		
		//al.Atualizar(al);
		
		//al.Deletar("2020");
		
	}

	
	public static boolean cadastrar(AlunoDAO aluno) {
		String sql = "insert into aluno (nome, nota, RA)"
				+ "value(?,?,?)";
		try (
				Connection conexao = Conexao.conecta();
				PreparedStatement Seta = conexao.prepareStatement(sql)
				)
		
		{
			Seta.setString(1, aluno.getNome());
			Seta.setFloat(2, aluno.getNota());
			Seta.setString(3, aluno.getRA());
			Seta.execute();
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
			
	}
	
	
	public static boolean Deletar(String RA) {
		String sql = "DELETE from aluno where RA = ?";
		try {
			Connection conexao = Conexao.conecta();
			PreparedStatement del = conexao.prepareStatement(sql);
			del.setString(1, RA);
			del.execute();
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
	}
	
	public boolean Atualizar(AlunoDAO aluno) {
		String sql = "UPDATE aluno set nome=?, nota=?, RA=? where RA=?";
		try {
			Connection conexao = Conexao.conecta();
			PreparedStatement att = conexao.prepareStatement(sql);
			att.setString(1, aluno.getNome());
			att.setFloat(2, aluno.getNota());
			att.setString(3, aluno.getRA());
			att.setString(4, aluno.getRA());
			att.execute();		
			return true;
			
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
	}
	
	
	public String Buscar(AlunoDAO al){
		String sql = "SELECT *from aluno WHERE RA=?";
		List<AlunoDAO> retorno = new ArrayList<>();
		try {
			Connection conexao = Conexao.conecta();
			PreparedStatement busc = conexao.prepareStatement(sql);
			
			busc.setString(1, al.getRA());
			
			ResultSet resultado = busc.executeQuery();
			
			while(resultado.next()) {
				AlunoDAO aluno = new AlunoDAO();
				aluno.setNome(resultado.getString("nome"));
				aluno.setNota(resultado.getFloat("nota"));
				aluno.setRA(resultado.getString("RA"));	
				
				System.out.println("Nome:"+ aluno.getNome());
				System.out.println("Nota:"+ aluno.getNota());
				System.out.println("RA:"+ aluno.getRA());
				retorno.add(aluno);
			}
			
			
		} catch (Exception e) {
			System.out.println(e);
			return "erro";
		}
		
		return "carregado";
	}
	
}
