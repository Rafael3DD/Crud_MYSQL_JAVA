package DAOMySQL;

import java.sql.*;


public class Conexao {
	public static Connection conecta() {
		java.sql.Connection conexao = null;
		String url = "jdbc:mysql://localhost:3306/estudo";
		String user = "root";
		String senha = "123456";
		
		
		try {
			conexao = DriverManager.getConnection(url, user, senha);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conexao;
	}
	
	
	
	
}
